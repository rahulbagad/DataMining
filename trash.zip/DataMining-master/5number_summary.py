import math

def median(lst):
    n = len(lst)
    if n < 1:
        return None
    if n % 2 == 1:
        return lst[(int)(n/2)]
    else:
        return sum(lst[(int)(n/2)-1:(int)(n/2)+1])/2.0
        

def Q1(Data):
    temp=Data[:(int)(len(Data)/2)]
    return median(temp)
    

def Q3(Data):
    if (len(Data)%2==0):
        temp=Data[int(len(Data)/2):]
    else:
        temp=Data[int(len(Data)/2)+1:]
    return median(temp)

DataSet=[int(x) for x in input("input values :").split()]
DataSet=sorted(DataSet)
print("5 number summary:")
print("Min:",min(DataSet))
print("Max",max(DataSet))
print("1st Quartile:",Q1(DataSet))
print("2nd Quartile:",median(DataSet))
print("3rd Quartile:",Q3(DataSet))
