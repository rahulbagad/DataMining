#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int>v;
	int n,i,j,no_of_bins,bin_size,x;
	cout<<"data:";
	do
	{
		cin>>x;
		if(x!=0)
			v.push_back(x);
	}while(x!=0);
	n=v.size();	
	cout<<"bin size:";
	cin>>bin_size;
	no_of_bins=(ceil)((float)n/bin_size);

	sort(v.begin(),v.end());
	if(n%2!=0)
		bin_size+=1;


	vector<int>bins[no_of_bins];

	int bno=0;
	
	for(i=0;i<n;i++)
	{

		bins[bno].push_back(v[i]);
		if(((i+1)%bin_size)==0)
			bno++;

	}

	cout<<"Equi-width Binning:"<<endl;
	for(i=0;i<no_of_bins;i++)
	{
		cout<<"bin_no -"<<i+1<<" : ";
		for(j=0;j<bins[i].size();j++)
		{
			cout<<bins[i][j]<<" ";
		}
		cout<<endl;
	}

	cout<<"-----------------------------------------------------------------"<<endl;

	cout<<"Bin Mean:"<<endl;
	double mean=0;
	for(i=0;i<no_of_bins;i++)
	{
		cout<<"bin_no -"<<i+1<<" : ";
		mean=0;
		for(j=0;j<bins[i].size();j++)
		{
			mean+=bins[i][j];
		}
		mean/=bins[i].size();
		for(j=0;j<bins[i].size();j++)
		{
			cout<<mean<<" ";
		}
		cout<<endl;
	}


	cout<<"--------------------------------------------------------------------"<<endl;
	cout<<"Bin Boundaries :"<<endl;
	mean=0;
	for(i=0;i<no_of_bins;i++)
	{
		cout<<"bin_no -"<<i+1<<" : ";
		int var_min=bins[i][0],var_max=bins[i][bins[i].size()-1];
		
		for(j=0;j<bins[i].size();j++)
		{
			if(j!=0&&j!=bins[i].size()-1)
			{
				if(abs(bins[i][j]-var_min)<=abs(bins[i][j]-var_max))
					cout<<var_min<<" ";
				else
					cout<<var_max<<" ";
			}		
				
			else
				cout<<bins[i][j]<<" ";
		}
		
		cout<<endl;
	}

	cout<<"----------------------------------------------------------------------"<<endl;

	return 0;
		
}
