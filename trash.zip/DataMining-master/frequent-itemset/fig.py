import csv
def prune(item_dict,minconf):
	freq=[]
	for item in item_dict:
		if item_dict[item]>minconf:
			freq.append(item)
	return freq

def generation(Itemset, length):
    item = []
    item_index = 0
    for i in range (0,length):
        e = str(Itemset[i])
        for j in range (i+1,length):
            e1 = str(Itemset[j])
            if e[0:(len(e)-1)] == e1[0:(len(e1)-1)]:
                    uset = e[0:(len(e)-1)]+e1[len(e1)-1]+e[len(e)-1] 
                    uset = ''.join(sorted(uset))
                    item.append(uset)
    return item


def subset_count(item,item_len):
    Lk = dict()
    file = open('example.txt')
    for l in file:
        l = str(l.split())
        count = 0
        for i in range (0,item_len):
            key = str(item[i])
            if key not in Lk:
                Lk[key] = 0
            flag = True
            for k in key:
                if k not in l:
                    flag = False
            if flag:
                Lk[key] += 1
    file.close()
    return Lk

item_dict={}


with open('ex.csv') as csvfile:
	data = csv.reader(csvfile, delimiter=',')
	for line in data:
		for i in line:
			if i not in item_dict:
				item_dict[i]=1
			else:
				item_dict[i]+=1

l1=prune(item_dict,2)
l=generation(l1,len(l1))
while l!=[]:
	