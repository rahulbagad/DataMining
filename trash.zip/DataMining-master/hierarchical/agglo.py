import pandas as pd
import numpy as np

def minIndex(mat):
    min_el=999999999
    lst=[0]*2
    for i in range(len(mat)):
        for j in range(len(mat)):
            if min_el>mat[i][j] and mat[i][j]!=0:
                min_el=mat[i][j]
                lst[0]=i
                lst[1]=j        
    return lst


def update(arr,i,y):
    for j in range(len(arr)):
        arr[i][j]=min(arr[i][j],arr[y][j])
        arr[j][i]=arr[i][j]
    return arr
        
df=pd.read_csv('agg.csv',header=None)
mat=df.as_matrix()
arr=np.array(mat)
ans=[]
dict={}
for i in range(len(arr)):
    dict[i]=str(i)

n=len(dict)


for i in range(len(dict)):
    print(dict[i],end=" ")

print()
print(arr)
while(len(arr)>=2):
    l=minIndex(arr)
    dict[l[0]]=str(dict[l[0]])+str(dict[l[1]])
    for i in range(0,n-1):
        print(dict[i],end=" ")
    n-=1
    print()

    for i in range(len(dict)-1):
        if i>=l[1]:
            dict[i]=dict[i+1]          
   
    arr=update(arr,l[0],l[1])
    arr=np.delete(arr,l[1],0)
    arr=np.delete(arr,l[1],1)
    print(arr)

