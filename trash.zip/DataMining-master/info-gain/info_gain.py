import numpy as np
import pandas as pd
from math import *

def info_gain(data, attr, tattr):
    f = {}
    sub_ent = 0.0
    for i in data[attr]:
        if i in f:
            f[i] += 1.0
        else:
            f[i]  = 1.0
    for val in f:
        val_prob = f[val]/sum(f.values())     
        d=pd.DataFrame()
        for i in range(len(data)):
            if data.loc[i][attr]==val:
                d=d.append(data.loc[i])  
                
        sub_ent += val_prob * calc_entropy(d, tattr) 
    return (calc_entropy(data, tattr) - sub_ent)


def calc_entropy(data, tattr):
    f = {}
    dat_ent = 0.0
    for i in data[tattr]:
        if i in f.keys():
            f[i]+=1.0
        else:
            f[i]=1
    for freq in f.values():
        dat_ent += (-freq/len(data)) * log(freq/len(data), 2) 
    return dat_ent



df=pd.read_csv("play.csv")
print(df)


for i in list(df):
    print("information gain(",i,")-> ",info_gain(df,i,'play'))

