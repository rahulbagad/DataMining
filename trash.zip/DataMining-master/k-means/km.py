from math import sqrt
import numpy as np
import pandas as pd
import random


df=pd.read_csv('x.csv')
n=int(input('No of Clusters:'))


def main(k):
    v1=df['V1']
    v2=df['V2']
    data = [[v1[i], v2[i]] for i in range(len(v1))]
    cent=kmeans(data,k)
    i=0
    for item in cent:
        print('Cluster ',i,' centroid:',item)
        i+=1
    print(df)
    count_by_cluster(df,k)


def count_by_cluster(data,k):
    for i in range(0,k):
        print('cluster ',i,'contains',(data.iloc[:,-1][data.iloc[:,-1]==i]).count(),'points')

def kmeans(data, K):
    c1 = k_random_points(K, data)
    c2=np.zeros(c1.shape)
    while dist(c1,c2):
        index = assign(data, c1)
        c2=c1
        c1 = update(data, index, K)
    df['index']=index
    return c1

def k_random_points(K, data):
    data = np.array(data)
    index = random.sample(range(len(data)), K)
    c1 = data[index,:]
    return c1

def assign(data, c1):
    n = len(data)
    K = len(c1)

    index = [0] * n

    for i in range(n):
        update = distance(data[i], c1[0])
        for j in range(1, K):
            dis = distance(data[i], c1[j])
            if dis < update:
                index[i] = j
                update = dis              
    return index

def update(data,index,K):
    dim = len(data[0])
    point_sum = [[0] * dim for x in range(K)]
    c1 = [[0] * dim for x in range(K)]
    cnt = K * [0]
    for i in range(len(data)):
        cnt[index[i]] += 1
        for j in range(dim):
            point_sum[index[i]][j] = data[i][j] + point_sum[index[i]][j]

    for i in range(len(data)):
        for j in range(dim):
            c1[index[i]][j] = point_sum[index[i]][j] / cnt[index[i]]
    return c1

def dist(a, b):
    dist=0.0
    for i in range(len(a)):
        for x,y in zip(a[i],b[i]):
            dist+=(x-y)**2
    return sqrt(dist)

def distance(a, b):
    dist = 0
    for i, j in zip(a, b):
        dist +=(i-j)**2
    return sqrt(dist)

main(n)