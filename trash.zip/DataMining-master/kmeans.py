import csv
import random
import math

def kmeans(data,k):
	clust_init=krand(data,k)
	clust=[]
	for i in range(0,len(clust_init)):
		clust.append([0,0])
	while dist(clust_init,clust):
		index=assign(data,clust_init)
		clust=clust_init
		clust_init=update(data,index,k)
	print(index)
	return clust_init

def krand(data,k):
	rand=[]
	ind=random.sample(range(0,len(data)-1),k)
	for i in ind:
		rand.append(data[i])
	return rand

def assign(data, c1):
	n = len(data)
	K = len(c1)
	index = [0] * n
	for i in range(n):
		update = distance(data[i], c1[0])
		for j in range(1, K):
			dis = distance(data[i], c1[j])
			if dis < update:
				index[i] = j
				update = dis              
	return index

def update(data,index,K):
    dim = len(data[0])
    point_sum = [[0] * dim for x in range(K)]
   
    c1 = [[0] * dim for x in range(K)]
    print(c1)
    cnt = K * [0]
    for i in range(len(data)):
        cnt[index[i]] += 1
        for j in range(dim):
          	point_sum[index[i]][j] = int(data[i][j]) + point_sum[index[i]][j]

    for i in range(len(data)):
        for j in range(dim):
            c1[index[i]][j] = point_sum[index[i]][j] / cnt[index[i]]

    return c1


def dist(a, b):
	dist=0.0
	for i in range(len(a)):
		for x,y in zip(a[i],b[i]):
			x=int(x)
			y=int(y)
			dist+=(x-y)**2
	return math.sqrt(dist)

def distance(a, b):
	dist = 0
	for i, j in zip(a, b):
		i=int(i)
		j=int(j)
		dist +=(i-j)**2
	return math.sqrt(dist)

v1=[]
v2=[]


with open('x.csv', newline='') as csvfile:
	data = csv.reader(csvfile, delimiter=' ', quotechar='|')
	fl=True
	for row in data:
		if fl:
			fl=False
			continue
		v1.append(row[0][0])
		v2.append(row[0][2])
data = [[v1[i], v2[i]] for i in range(len(v1))]
k=input('enter no. of clust')
cent=kmeans(data,int(k))
print(cent)

		