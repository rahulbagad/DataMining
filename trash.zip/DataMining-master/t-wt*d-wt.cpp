#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i=0,j=0,n;
	cout<<"Enter no. of records:";
	cin>>n;
	vector<float >dept[8];
	cout<<"Enter Dept Id, placed, non-placed respectively:"<<endl;
	for(i=0;i<n;i++)
	{
		int dept_id,p,np;
		cin>>dept_id>>p>>np;
		dept[i].push_back(dept_id);
		dept[i].push_back(p);
		dept[i].push_back(np);
	}
	
	int pcnt=0,npcnt=0;
	for(i=0;i<n;i++)
	{
		pcnt+=dept[i][1];   //total placed count
		npcnt+=dept[i][2];  //total non-placed count
	}
	
	for(i=0;i<n;i++)
	{
		dept[i].push_back(dept[i][1]+dept[i][2]); //row-wise sum of placed and non-placed
	}
	
	for(i=0;i<n;i++)
	{
		dept[i].push_back(dept[i][1]/dept[i][3]); //t-weight for ith record(Placed)
		dept[i].push_back(dept[i][1]/(pcnt));// d-weight for ith record(Placed)
		
		dept[i].push_back(dept[i][2]/dept[i][3]); //t-weight for ith record(Non-Placed)
		dept[i].push_back(dept[i][2]/(npcnt)); //d-weight for ith record(Non-placed)
	
	}
	float dwtnp=0,dwtp=0;
	cout<<"resultant matrix:"<<endl;
	cout<<"DId         P         NP        T         TW1        DW1       TW2       DW2"<<endl;
	for(i=0;i<n;i++)
	{
		for(j=0;j<dept[i].size();j++)
		{
			if(j<=2)
				printf("%-10d",int(dept[i][j]));
			else
				printf("%10f",dept[i][j]);
			if(j==5)
				dwtp+=dept[i][j];  //calculation of total d-weight of placed 
			if(j==7)
				dwtnp+=dept[i][j]; //calculation of total d-weight of non-placed
		}
		cout<<endl;
	}
	cout<<"Check: dwtp and dwtnp should be 1"<<endl;
	cout<<dwtp<<" "<<dwtnp<<endl;
	return 0;
}
