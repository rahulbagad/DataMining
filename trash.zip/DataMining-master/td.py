import pandas as pd

df=pd.read_csv('data.csv')
print(df)
lst=df.columns.values
fl=True
df['tot']=0

for i in range(1,len(lst)):
        df['tot']+=df[lst[i]]
print(df)

for i in range(1,len(lst)):
        df['t-wt '+str(lst[i])]=round((df[lst[i]]/df['tot'])*100,2)
        df['d-wt '+str(lst[i])]=round(df[lst[i]]/sum(df[lst[i]])*100,2)

print(df)

